"use client";

import { useState, useEffect } from "react";
import WachHeader from "../../components/WachHeader";
import WachFooter from "../../components/WachFooter";
import { DayPicker } from "react-day-picker";
import "react-day-picker/dist/style.css";
import {
  Calendar,
  Clock,
  CheckCircle2,
  Loader2,
  User,
  Mail,
  Phone,
} from "lucide-react";

export default function BookingPage() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [availableTimes, setAvailableTimes] = useState([]);
  const [disabledDates, setDisabledDates] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    notes: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);

  // Load availability on mount
  useEffect(() => {
    loadAvailability();
  }, []);

  const loadAvailability = async () => {
    try {
      const response = await fetch("/api/availability");
      if (!response.ok) {
        throw new Error("Failed to load availability");
      }
      const data = await response.json();

      // Convert disabled dates strings to Date objects
      if (data.disabledDates) {
        const disabled = data.disabledDates.map((d) => new Date(d));
        setDisabledDates(disabled);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // When date is selected, show available times
  useEffect(() => {
    if (selectedDate) {
      // Get day of week (0 = Sunday, 6 = Saturday)
      const dayOfWeek = selectedDate.getDay();

      // Skip weekends
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        setAvailableTimes([]);
        return;
      }

      // Check if date is disabled
      const isDisabled = disabledDates.some(
        (d) => d.toDateString() === selectedDate.toDateString(),
      );

      if (isDisabled) {
        setAvailableTimes([]);
        return;
      }

      // Show available times (9 AM - 5 PM, excluding lunch 12-1 PM)
      const times = [
        "09:00 AM",
        "10:00 AM",
        "11:00 AM",
        "02:00 PM",
        "03:00 PM",
        "04:00 PM",
      ];
      setAvailableTimes(times);
      setSelectedTime(null);
    }
  }, [selectedDate, disabledDates]);

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setError(null);
  };

  const handleTimeSelect = (time) => {
    setSelectedTime(time);
    setError(null);
  };

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!selectedDate) {
      setError("Please select a date");
      return;
    }

    if (!selectedTime) {
      setError("Please select a time");
      return;
    }

    if (!formData.name || !formData.email || !formData.phone) {
      setError("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/submit-booking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: selectedDate.toISOString(),
          time: selectedTime,
          ...formData,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error submitting booking: ${response.status}`);
      }

      setSubmitted(true);
    } catch (err) {
      console.error(err);
      setError("Failed to submit booking. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#121212]">
        <WachHeader />
        <div className="min-h-screen flex items-center justify-center px-6 pt-20">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-24 h-24 rounded-full bg-[#007fff]/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={48} className="text-[#007fff]" />
            </div>
            <h1
              className="text-4xl md:text-5xl font-bold text-white mb-4"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              Booking Confirmed!
            </h1>
            <p
              className="text-white/70 text-lg mb-4"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Your session has been successfully booked for{" "}
              <span className="text-[#007fff] font-semibold">
                {selectedDate.toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>{" "}
              at{" "}
              <span className="text-[#007fff] font-semibold">
                {selectedTime}
              </span>
              .
            </p>
            <p
              className="text-white/60 mb-8"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              You'll receive a confirmation email and SMS with all the details
              shortly.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="/"
                className="bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Back to Home
              </a>
              <a
                href="/onboarding"
                className="border-2 border-[#007fff] text-[#007fff] hover:bg-[#007fff] hover:text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Start Onboarding
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      <WachHeader />

      <section className="bg-gradient-to-b from-[#0A0A0A] to-[#121212] pt-32 pb-20 px-6 min-h-screen">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1
              className="text-[clamp(2.5rem,7vw,4.5rem)] leading-[1.1] font-bold text-white mb-6"
              style={{
                fontFamily: "Poppins, sans-serif",
                letterSpacing: "-0.5px",
              }}
            >
              Book a{" "}
              <span className="relative inline-block">
                Session
                <svg
                  className="absolute left-0 -bottom-2 w-full h-3 opacity-50"
                  viewBox="0 0 100 8"
                  fill="none"
                >
                  <path
                    d="M2 6c20-4 40-4 60 0s40 4 36-2"
                    stroke="#007fff"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </h1>
            <p
              className="text-white/60 text-lg md:text-xl max-w-3xl mx-auto"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Schedule a consultation to discuss your video project needs.
              Select your preferred date and time.
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 mb-6 max-w-3xl mx-auto">
              <p
                className="text-red-400 text-sm text-center"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {error}
              </p>
            </div>
          )}

          {/* Booking Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Calendar Section */}
            <div className="bg-[#1A1A1A] rounded-2xl p-8 border border-white/10">
              <div className="flex items-center gap-3 mb-6">
                <Calendar size={28} className="text-[#007fff]" />
                <h2
                  className="text-2xl font-bold text-white"
                  style={{ fontFamily: "Poppins, sans-serif" }}
                >
                  Select a Date
                </h2>
              </div>

              <div className="booking-calendar">
                <DayPicker
                  mode="single"
                  selected={selectedDate}
                  onSelect={handleDateSelect}
                  disabled={[
                    { before: new Date() },
                    { dayOfWeek: [0, 6] }, // Disable weekends
                    ...disabledDates,
                  ]}
                  modifiersClassNames={{
                    selected: "bg-[#007fff] text-white rounded-full",
                    today: "font-bold text-[#007fff]",
                  }}
                  className="mx-auto"
                />
              </div>

              <p
                className="text-white/50 text-sm mt-4 text-center"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                * Weekends are not available
              </p>
            </div>

            {/* Time & Details Section */}
            <div className="space-y-6">
              {/* Time Selection */}
              <div className="bg-[#1A1A1A] rounded-2xl p-8 border border-white/10">
                <div className="flex items-center gap-3 mb-6">
                  <Clock size={28} className="text-[#007fff]" />
                  <h2
                    className="text-2xl font-bold text-white"
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    Select a Time
                  </h2>
                </div>

                {!selectedDate ? (
                  <p
                    className="text-white/60 text-center py-8"
                    style={{ fontFamily: "Montserrat, sans-serif" }}
                  >
                    Please select a date first
                  </p>
                ) : availableTimes.length === 0 ? (
                  <p
                    className="text-white/60 text-center py-8"
                    style={{ fontFamily: "Montserrat, sans-serif" }}
                  >
                    No available times for this date
                  </p>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {availableTimes.map((time) => (
                      <button
                        key={time}
                        onClick={() => handleTimeSelect(time)}
                        className={`py-3 px-4 rounded-lg font-semibold text-sm transition-all duration-200 ${
                          selectedTime === time
                            ? "bg-[#007fff] text-white"
                            : "bg-[#0A0A0A] text-white/80 border border-white/20 hover:border-[#007fff]"
                        }`}
                        style={{ fontFamily: "Montserrat, sans-serif" }}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Contact Details */}
              <div className="bg-[#1A1A1A] rounded-2xl p-8 border border-white/10">
                <div className="flex items-center gap-3 mb-6">
                  <User size={28} className="text-[#007fff]" />
                  <h2
                    className="text-2xl font-bold text-white"
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    Your Details
                  </h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label
                      className="block text-white/80 text-sm mb-2 font-medium"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      Full Name <span className="text-[#007fff]">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) =>
                        handleInputChange("name", e.target.value)
                      }
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  </div>

                  <div>
                    <label
                      className="block text-white/80 text-sm mb-2 font-medium"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      Email <span className="text-[#007fff]">*</span>
                    </label>
                    <input
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      onChange={(e) =>
                        handleInputChange("email", e.target.value)
                      }
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  </div>

                  <div>
                    <label
                      className="block text-white/80 text-sm mb-2 font-medium"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      Phone <span className="text-[#007fff]">*</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="+234 800 000 0000"
                      value={formData.phone}
                      onChange={(e) =>
                        handleInputChange("phone", e.target.value)
                      }
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  </div>

                  <div>
                    <label
                      className="block text-white/80 text-sm mb-2 font-medium"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      Notes (Optional)
                    </label>
                    <textarea
                      placeholder="Any specific topics you'd like to discuss..."
                      value={formData.notes}
                      onChange={(e) =>
                        handleInputChange("notes", e.target.value)
                      }
                      rows={3}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors resize-none"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  </div>
                </div>
              </div>

              {/* Pricing Info */}
              <div className="bg-gradient-to-r from-[#007fff]/10 to-[#007fff]/5 rounded-2xl p-6 border border-[#007fff]/30">
                <p
                  className="text-white/80 text-sm mb-2"
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  <span className="font-bold">Session Fee:</span> ₦5,000
                  (refundable if you book a project)
                </p>
                <p
                  className="text-white/60 text-xs"
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  This consultation fee will be deducted from your final project
                  cost.
                </p>
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="w-full bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-lg px-8 py-4 rounded-full transition-all duration-200 hover:shadow-[0_0_30px_rgba(0,127,255,0.5)] hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={22} className="animate-spin" />
                    Booking...
                  </>
                ) : (
                  <>
                    Confirm Booking
                    <CheckCircle2 size={22} />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </section>

      <WachFooter />

      <style jsx global>{`
        .booking-calendar {
          --rdp-cell-size: 45px;
          --rdp-accent-color: #007fff;
          --rdp-background-color: #007fff;
        }

        .booking-calendar .rdp {
          --rdp-cell-size: 45px;
          margin: 0 auto;
        }

        .booking-calendar .rdp-months {
          justify-content: center;
        }

        .booking-calendar .rdp-month {
          color: white;
        }

        .booking-calendar .rdp-caption {
          color: white;
          font-weight: 600;
          margin-bottom: 1rem;
        }

        .booking-calendar .rdp-head_cell {
          color: rgba(255, 255, 255, 0.6);
          font-weight: 500;
          font-size: 0.875rem;
        }

        .booking-calendar .rdp-day {
          color: rgba(255, 255, 255, 0.8);
          font-weight: 500;
        }

        .booking-calendar .rdp-day:hover:not(.rdp-day_selected):not(.rdp-day_disabled) {
          background-color: rgba(0, 127, 255, 0.1);
          color: white;
        }

        .booking-calendar .rdp-day_selected {
          background-color: #007fff;
          color: white;
          font-weight: 700;
        }

        .booking-calendar .rdp-day_disabled {
          color: rgba(255, 255, 255, 0.2);
          text-decoration: line-through;
        }

        .booking-calendar .rdp-button:hover:not([disabled]) {
          background-color: rgba(0, 127, 255, 0.1);
        }
      `}</style>
    </div>
  );
}
