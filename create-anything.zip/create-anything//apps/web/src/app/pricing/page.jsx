import WachHeader from "../../components/WachHeader";
import WachFooter from "../../components/WachFooter";
import { Check, ArrowRight } from "lucide-react";

export default function PricingPage() {
  const pricingTiers = [
    {
      name: "Basic",
      price: "₦20,000",
      description: "Perfect for simple video projects and social media content",
      features: [
        "Up to 2 2minutes video length",
        "Basic color correction",
        "Simple transitions",
        "Background music",
        "1 revision round",
        "720p HD export",
        "5-7 days delivery",
      ],
      recommended: false,
      ctaText: "Get Started",
      ctaLink: "/onboarding",
    },
    {
      name: "Advanced",
      price: "₦50,000",
      description: "Ideal for professional content and marketing videos",
      features: [
        "Up to 3 3minutes video length",
        "Advanced color grading",
        "Motion graphics & titles",
        "Sound design & mixing",
        "3 revision rounds",
        "1080p Full HD export",
        "Custom transitions",
        "3-5 days delivery",
      ],
      recommended: true,
      ctaText: "Get Started",
      ctaLink: "/onboarding",
    },
    {
      name: "Premium",
      price: "₦200,000",
      description: "For high-end productions and commercial projects",
      features: [
        "Up to 10 3minutes video length",
        "Cinematic color grading",
        "Advanced motion graphics",
        "VFX & special effects",
        "Sound design & mastering",
        "Unlimited revision rounds",
        "4K Ultra HD export",
        "Priority support",
        "1-3 days delivery",
      ],
      recommended: false,
      ctaText: "Get Started",
      ctaLink: "/onboarding",
    },
    {
      name: "Custom",
      price: "Let's Talk",
      description:
        "Tailored solutions for unique projects and ongoing partnerships",
      features: [
        "Custom video length",
        "Personalized workflow",
        "Dedicated project manager",
        "Custom color grading",
        "Full creative control",
        "All premium features",
        "Flexible delivery timeline",
        "Long-term partnership options",
      ],
      recommended: false,
      ctaText: "Contact Us",
      ctaLink: "/onboarding",
    },
  ];

  return (
    <div className="min-h-screen bg-[#121212]">
      <WachHeader />

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-[#0A0A0A] to-[#121212] pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1
            className="text-[clamp(2.5rem,7vw,4.5rem)] leading-[1.1] font-bold text-white mb-6"
            style={{
              fontFamily: "Poppins, sans-serif",
              letterSpacing: "-0.5px",
            }}
          >
            Simple, Transparent{" "}
            <span className="relative inline-block">
              Pricing
              <svg
                className="absolute left-0 -bottom-2 w-full h-3 opacity-50"
                viewBox="0 0 100 8"
                fill="none"
              >
                <path
                  d="M2 6c20-4 40-4 60 0s40 4 36-2"
                  stroke="#007fff"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </h1>
          <p
            className="text-white/60 text-lg md:text-xl max-w-3xl mx-auto"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Choose the perfect plan for your video editing needs. All prices are
            in Nigerian Naira (₦)
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="bg-[#121212] py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pricingTiers.map((tier, index) => (
              <div
                key={index}
                className={`relative rounded-2xl p-8 transition-all duration-300 hover:scale-105 ${
                  tier.recommended
                    ? "bg-gradient-to-b from-[#007fff] to-[#0066cc] shadow-[0_0_40px_rgba(0,127,255,0.3)]"
                    : "bg-[#1A1A1A] border border-white/10 hover:border-[#007fff]/50"
                }`}
              >
                {tier.recommended && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span
                      className="bg-white text-[#007fff] text-sm font-bold px-4 py-1 rounded-full"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      RECOMMENDED
                    </span>
                  </div>
                )}

                {/* Tier Name */}
                <h3
                  className={`text-2xl font-bold mb-2 ${
                    tier.recommended ? "text-white" : "text-white"
                  }`}
                  style={{ fontFamily: "Poppins, sans-serif" }}
                >
                  {tier.name}
                </h3>

                {/* Price */}
                <div className="mb-4">
                  <span
                    className={`text-4xl font-extrabold ${
                      tier.recommended ? "text-white" : "text-[#007fff]"
                    }`}
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    {tier.price}
                  </span>
                </div>

                {/* Description */}
                <p
                  className={`text-sm mb-6 ${
                    tier.recommended ? "text-white/90" : "text-white/60"
                  }`}
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  {tier.description}
                </p>

                {/* Features List */}
                <ul className="space-y-3 mb-8">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                          tier.recommended ? "bg-white/20" : "bg-[#007fff]/20"
                        }`}
                      >
                        <Check
                          size={14}
                          className={
                            tier.recommended ? "text-white" : "text-[#007fff]"
                          }
                          strokeWidth={3}
                        />
                      </div>
                      <span
                        className={`text-sm ${
                          tier.recommended ? "text-white/90" : "text-white/70"
                        }`}
                        style={{ fontFamily: "Montserrat, sans-serif" }}
                      >
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <a
                  href={tier.ctaLink}
                  className={`w-full flex items-center justify-center gap-2 font-semibold text-base px-6 py-3 rounded-full transition-all duration-200 ${
                    tier.recommended
                      ? "bg-white text-[#007fff] hover:bg-white/90"
                      : "bg-[#007fff] text-white hover:bg-[#0066cc]"
                  }`}
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  {tier.ctaText}
                  <ArrowRight size={18} />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-[#121212] py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2
            className="text-3xl md:text-4xl font-bold text-white text-center mb-12"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div className="bg-[#1A1A1A] rounded-lg p-6 border border-white/10">
              <h3
                className="text-xl font-bold text-white mb-2"
                style={{ fontFamily: "Poppins, sans-serif" }}
              >
                What's included in a revision round?
              </h3>
              <p
                className="text-white/60"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                A revision round includes changes to timing, transitions, color
                adjustments, and minor edits based on your feedback.
              </p>
            </div>

            <div className="bg-[#1A1A1A] rounded-lg p-6 border border-white/10">
              <h3
                className="text-xl font-bold text-white mb-2"
                style={{ fontFamily: "Poppins, sans-serif" }}
              >
                How does the payment work?
              </h3>
              <p
                className="text-white/60"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                We require 50% upfront payment to begin work, with the remaining
                50% due upon project completion before final delivery.
              </p>
            </div>

            <div className="bg-[#1A1A1A] rounded-lg p-6 border border-white/10">
              <h3
                className="text-xl font-bold text-white mb-2"
                style={{ fontFamily: "Poppins, sans-serif" }}
              >
                Can I upgrade my plan later?
              </h3>
              <p
                className="text-white/60"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Yes! You can upgrade to a higher tier at any time. We'll credit
                the amount you've already paid towards the new plan.
              </p>
            </div>

            <div className="bg-[#1A1A1A] rounded-lg p-6 border border-white/10">
              <h3
                className="text-xl font-bold text-white mb-2"
                style={{ fontFamily: "Poppins, sans-serif" }}
              >
                What if I need something not listed in any plan?
              </h3>
              <p
                className="text-white/60"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                That's what our Custom plan is for! Contact us and we'll create
                a personalized package that fits your exact requirements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-b from-[#121212] to-[#0A0A0A] py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2
            className="text-3xl md:text-4xl font-bold text-white mb-6"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            Still Not Sure Which Plan to Choose?
          </h2>
          <p
            className="text-white/70 text-lg mb-8 max-w-2xl mx-auto"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Let's have a conversation about your project needs and find the
            perfect solution together.
          </p>
          <a
            href="/onboarding"
            className="inline-flex items-center gap-2 bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-lg px-12 py-4 rounded-full transition-all duration-200 hover:shadow-[0_0_30px_rgba(0,127,255,0.5)] hover:scale-105"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Get Started Now
            <ArrowRight size={22} />
          </a>
        </div>
      </section>

      <WachFooter />
    </div>
  );
}