import sql from "../utils/sql";

export async function GET(request) {
  try {
    // Get all unavailable dates from the database
    const unavailableDates = await sql`
      SELECT unavailable_date, reason 
      FROM unavailable_dates
      ORDER BY unavailable_date ASC
    `;

    // Also get dates that already have bookings (optional - to show fully booked days)
    const bookedDates = await sql`
      SELECT booking_date, COUNT(*) as booking_count
      FROM bookings
      WHERE status = 'confirmed'
      GROUP BY booking_date
      HAVING COUNT(*) >= 6
    `;

    // Combine unavailable dates and fully booked dates
    const allDisabledDates = [
      ...unavailableDates.map((d) => d.unavailable_date),
      ...bookedDates.map((d) => d.booking_date),
    ];

    return Response.json({
      disabledDates: allDisabledDates,
      unavailableReasons: unavailableDates.reduce((acc, d) => {
        acc[d.unavailable_date] = d.reason;
        return acc;
      }, {}),
    });
  } catch (error) {
    console.error("Error fetching availability:", error);
    return Response.json(
      { error: "Failed to fetch availability" },
      { status: 500 },
    );
  }
}
