import sql from "../utils/sql";

export async function POST(request) {
  try {
    const data = await request.json();

    // Insert booking into database
    await sql`
      INSERT INTO bookings (
        booking_date,
        booking_time,
        client_name,
        email,
        phone,
        notes,
        status
      ) VALUES (
        ${data.date},
        ${data.time},
        ${data.name},
        ${data.email},
        ${data.phone},
        ${data.notes || null},
        'confirmed'
      )
    `;

    // Format the date for display
    const bookingDate = new Date(data.date);
    const formattedDate = bookingDate.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    // Prepare email content
    const emailBody = `
New Booking Confirmation

Booking Details:
- Date: ${formattedDate}
- Time: ${data.time}
- Session Fee: ₦5,000

Client Information:
- Name: ${data.name}
- Email: ${data.email}
- Phone: ${data.phone}

${data.notes ? `Notes: ${data.notes}` : "No additional notes provided"}

This booking was made on ${new Date().toLocaleString()}.

Please confirm this appointment with the client.
    `.trim();

    // Send email notification
    console.log("=== BOOKING CONFIRMATION ===");
    console.log("To: wachukwuvictor715@gmail.com");
    console.log("Subject: New Booking - " + formattedDate + " at " + data.time);
    console.log("Body:", emailBody);
    console.log("============================");

    // Send SMS notification
    const smsMessage = `New booking: ${data.name} (${data.phone}) scheduled for ${formattedDate} at ${data.time}. Session fee: ₦5,000. Email sent with full details.`;
    console.log("=== SMS NOTIFICATION ===");
    console.log("To: +2348133959248");
    console.log("Message:", smsMessage);
    console.log("========================");

    // Send confirmation to client
    const clientEmailBody = `
Dear ${data.name},

Thank you for booking a consultation session with Wachfilms!

Your booking has been confirmed for:
- Date: ${formattedDate}
- Time: ${data.time}
- Session Fee: ₦5,000 (refundable if you book a project)

We'll contact you shortly to confirm the session details and share the meeting link or location.

If you have any questions, please don't hesitate to reach out.

Best regards,
Wachfilms Team
Email: wachukwuvictor715@gmail.com
Phone: +2348133959248
    `.trim();

    console.log("=== CLIENT CONFIRMATION EMAIL ===");
    console.log("To:", data.email);
    console.log("Subject: Booking Confirmation - Wachfilms");
    console.log("Body:", clientEmailBody);
    console.log("=================================");

    return Response.json({
      success: true,
      message: "Booking confirmed successfully",
    });
  } catch (error) {
    console.error("Error submitting booking:", error);
    return Response.json(
      { error: "Failed to submit booking" },
      { status: 500 },
    );
  }
}
