import sql from "../utils/sql";

export async function POST(request) {
  try {
    const data = await request.json();

    // Insert into database
    await sql`
      INSERT INTO questionnaire_responses (
        full_name,
        email,
        phone,
        company_name,
        project_type,
        project_goal,
        target_audience,
        video_length,
        deadline,
        budget,
        has_footage,
        editing_style,
        reference_videos,
        platforms,
        need_motion_graphics,
        need_color_grading,
        need_sound,
        revisions,
        brand_guidelines,
        additional_info
      ) VALUES (
        ${data.fullName},
        ${data.email},
        ${data.phone},
        ${data.companyName},
        ${data.projectType},
        ${data.projectGoal},
        ${data.targetAudience},
        ${data.videoLength},
        ${data.deadline},
        ${data.budget},
        ${data.hasFootage},
        ${data.editingStyle},
        ${data.referenceVideos || null},
        ${data.platforms},
        ${data.needMotionGraphics},
        ${data.needColorGrading},
        ${data.needSound},
        ${data.revisions},
        ${data.brandGuidelines || null},
        ${data.additionalInfo || null}
      )
    `;

    // Prepare email content
    const emailBody = `
New Client Questionnaire Submission

Client Information:
- Name: ${data.fullName}
- Email: ${data.email}
- Phone: ${data.phone}
- Company: ${data.companyName}

Project Details:
- Project Type: ${data.projectType}
- Project Goal: ${data.projectGoal}
- Target Audience: ${data.targetAudience}
- Desired Length: ${data.videoLength}
- Deadline: ${data.deadline}
- Budget: ${data.budget}

Production Requirements:
- Existing Footage: ${data.hasFootage}
- Editing Style: ${data.editingStyle}
- Platforms: ${data.platforms}
- Motion Graphics: ${data.needMotionGraphics}
- Color Grading: ${data.needColorGrading}
- Sound Requirements: ${data.needSound}
- Revision Rounds: ${data.revisions}

Additional Information:
- Reference Videos: ${data.referenceVideos || "None provided"}
- Brand Guidelines: ${data.brandGuidelines || "None provided"}
- Additional Notes: ${data.additionalInfo || "None provided"}

This submission was received on ${new Date().toLocaleString()}.
    `.trim();

    // Send email notification (using console.log as placeholder - you can integrate with email service)
    console.log("=== QUESTIONNAIRE SUBMISSION ===");
    console.log("To: wachukwuvictor715@gmail.com");
    console.log("Subject: New Client Questionnaire from " + data.fullName);
    console.log("Body:", emailBody);
    console.log("================================");

    // Send SMS notification (using console.log as placeholder - you can integrate with SMS service)
    const smsMessage = `New client questionnaire from ${data.fullName} (${data.email}). Project: ${data.projectType}. Budget: ${data.budget}. Check email for full details.`;
    console.log("=== SMS NOTIFICATION ===");
    console.log("To: +2348133959248");
    console.log("Message:", smsMessage);
    console.log("========================");

    return Response.json({
      success: true,
      message: "Questionnaire submitted successfully",
    });
  } catch (error) {
    console.error("Error submitting questionnaire:", error);
    return Response.json(
      { error: "Failed to submit questionnaire" },
      { status: 500 },
    );
  }
}
