"use client";

import { useState } from "react";
import WachHeader from "../../components/WachHeader";
import WachFooter from "../../components/WachFooter";
import { ArrowRight, ArrowLeft, CheckCircle2, Loader2 } from "lucide-react";

export default function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);

  const questions = [
    {
      id: "fullName",
      question: "What is your full name?",
      type: "text",
      placeholder: "Enter your full name",
      required: true,
    },
    {
      id: "email",
      question: "What is your email address?",
      type: "email",
      placeholder: "your.email@example.com",
      required: true,
    },
    {
      id: "phone",
      question: "What is your phone number?",
      type: "tel",
      placeholder: "+234 800 000 0000",
      required: true,
    },
    {
      id: "companyName",
      question: "What is your company/brand name?",
      type: "text",
      placeholder: "Your company or brand name",
      required: true,
    },
    {
      id: "projectType",
      question: "What type of video project do you need?",
      type: "select",
      options: [
        "Corporate Video",
        "Wedding",
        "Music Video",
        "Social Media Content",
        "Documentary",
        "Commercial",
        "Event Coverage",
        "Other",
      ],
      required: true,
    },
    {
      id: "projectGoal",
      question: "What is the primary goal of this video?",
      type: "select",
      options: [
        "Marketing/Promotion",
        "Entertainment",
        "Education/Training",
        "Brand Awareness",
        "Product Launch",
        "Event Documentation",
        "Other",
      ],
      required: true,
    },
    {
      id: "targetAudience",
      question: "Who is your target audience?",
      type: "textarea",
      placeholder: "Describe your target audience...",
      required: true,
    },
    {
      id: "videoLength",
      question: "What is your desired video length?",
      type: "select",
      options: [
        "Under 1 minute",
        "1-3 minutes",
        "3-5 minutes",
        "5-10 minutes",
        "10-15 minutes",
        "15-30 minutes",
        "Over 30 minutes",
      ],
      required: true,
    },
    {
      id: "deadline",
      question: "What is your project deadline?",
      type: "date",
      required: true,
    },
    {
      id: "budget",
      question: "What is your budget range?",
      type: "select",
      options: [
        "Under ₦20,000",
        "₦20,000 - ₦50,000",
        "₦50,000 - ₦100,000",
        "₦100,000 - ₦200,000",
        "Over ₦200,000",
        "Flexible",
      ],
      required: true,
    },
    {
      id: "hasFootage",
      question:
        "Do you have existing footage, or do you need filming services as well?",
      type: "select",
      options: [
        "I have all footage ready",
        "I have some footage, need additional filming",
        "I need complete filming services",
      ],
      required: true,
    },
    {
      id: "editingStyle",
      question: "What style of editing do you prefer?",
      type: "select",
      options: [
        "Cinematic",
        "Fast-paced/Dynamic",
        "Minimal/Clean",
        "Documentary Style",
        "Corporate/Professional",
        "Creative/Artistic",
        "Not sure yet",
      ],
      required: true,
    },
    {
      id: "referenceVideos",
      question: "Do you have any reference videos that inspire you?",
      type: "textarea",
      placeholder: "Share links or describe the style you're looking for...",
      required: false,
    },
    {
      id: "platforms",
      question: "What platforms will this video be used on?",
      type: "textarea",
      placeholder: "e.g., YouTube, Instagram, TikTok, Website, TV, etc.",
      required: true,
    },
    {
      id: "needMotionGraphics",
      question: "Do you need motion graphics, animations, or special effects?",
      type: "select",
      options: ["Yes", "No", "Not sure"],
      required: true,
    },
    {
      id: "needColorGrading",
      question: "Do you need color grading/color correction?",
      type: "select",
      options: ["Yes", "No", "Not sure"],
      required: true,
    },
    {
      id: "needSound",
      question: "Do you need sound design, music, or voiceover?",
      type: "textarea",
      placeholder: "Describe your sound requirements...",
      required: true,
    },
    {
      id: "revisions",
      question: "How many revision rounds do you expect?",
      type: "select",
      options: ["1 round", "2-3 rounds", "3-5 rounds", "Unlimited", "Not sure"],
      required: true,
    },
    {
      id: "brandGuidelines",
      question:
        "Do you have brand guidelines or specific colors/fonts to follow?",
      type: "textarea",
      placeholder: "Share details about your brand guidelines...",
      required: false,
    },
    {
      id: "additionalInfo",
      question: "Any additional information or special requirements?",
      type: "textarea",
      placeholder:
        "Share any other details that would help us understand your project better...",
      required: false,
    },
  ];

  const questionsPerStep = 4;
  const totalSteps = Math.ceil(questions.length / questionsPerStep);
  const currentQuestions = questions.slice(
    currentStep * questionsPerStep,
    (currentStep + 1) * questionsPerStep,
  );

  const handleInputChange = (id, value) => {
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleNext = () => {
    const currentStepQuestions = questions.slice(
      currentStep * questionsPerStep,
      (currentStep + 1) * questionsPerStep,
    );

    const missingRequired = currentStepQuestions.find(
      (q) => q.required && !formData[q.id],
    );

    if (missingRequired) {
      setError(`Please answer: ${missingRequired.question}`);
      return;
    }

    setError(null);
    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    setError(null);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    const allQuestions = questions;
    const missingRequired = allQuestions.find(
      (q) => q.required && !formData[q.id],
    );

    if (missingRequired) {
      setError(`Please answer: ${missingRequired.question}`);
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/submit-questionnaire", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error(`Error submitting questionnaire: ${response.status}`);
      }

      setSubmitted(true);
    } catch (err) {
      console.error(err);
      setError("Failed to submit. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#121212]">
        <WachHeader />
        <div className="min-h-screen flex items-center justify-center px-6 pt-20">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-24 h-24 rounded-full bg-[#007fff]/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={48} className="text-[#007fff]" />
            </div>
            <h1
              className="text-4xl md:text-5xl font-bold text-white mb-4"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              Thank You!
            </h1>
            <p
              className="text-white/70 text-lg mb-8"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Your responses have been submitted successfully. We'll review your
              project details and get back to you shortly via email and phone.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="/"
                className="bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Back to Home
              </a>
              <a
                href="/booking"
                className="border-2 border-[#007fff] text-[#007fff] hover:bg-[#007fff] hover:text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Book a Session
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      <WachHeader />

      <section className="bg-gradient-to-b from-[#0A0A0A] to-[#121212] pt-32 pb-20 px-6 min-h-screen">
        <div className="max-w-3xl mx-auto">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span
                className="text-white/60 text-sm font-medium"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Step {currentStep + 1} of {totalSteps}
              </span>
              <span
                className="text-white/60 text-sm font-medium"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {Math.round(((currentStep + 1) / totalSteps) * 100)}% Complete
              </span>
            </div>
            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#007fff] transition-all duration-300"
                style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Header */}
          <div className="text-center mb-12">
            <h1
              className="text-3xl md:text-4xl font-bold text-white mb-4"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              Let's Get Started
            </h1>
            <p
              className="text-white/60 text-lg"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Help us understand your project better by answering a few
              questions
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 mb-6">
              <p
                className="text-red-400 text-sm"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {error}
              </p>
            </div>
          )}

          {/* Questions */}
          <div className="space-y-8 mb-12">
            {currentQuestions.map((q, index) => (
              <div
                key={q.id}
                className="bg-[#1A1A1A] rounded-lg p-6 border border-white/10"
              >
                <label className="block mb-4">
                  <span
                    className="text-white text-lg font-semibold mb-2 block"
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    {currentStep * questionsPerStep + index + 1}. {q.question}
                    {q.required && (
                      <span className="text-[#007fff] ml-1">*</span>
                    )}
                  </span>

                  {q.type === "text" && (
                    <input
                      type="text"
                      placeholder={q.placeholder}
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  )}

                  {q.type === "email" && (
                    <input
                      type="email"
                      placeholder={q.placeholder}
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  )}

                  {q.type === "tel" && (
                    <input
                      type="tel"
                      placeholder={q.placeholder}
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  )}

                  {q.type === "date" && (
                    <input
                      type="date"
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  )}

                  {q.type === "select" && (
                    <select
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#007fff] transition-colors"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      <option value="">Select an option</option>
                      {q.options.map((option, i) => (
                        <option key={i} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  )}

                  {q.type === "textarea" && (
                    <textarea
                      placeholder={q.placeholder}
                      value={formData[q.id] || ""}
                      onChange={(e) => handleInputChange(q.id, e.target.value)}
                      rows={4}
                      className="w-full bg-[#0A0A0A] border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:border-[#007fff] transition-colors resize-none"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    />
                  )}
                </label>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className={`flex items-center gap-2 font-semibold text-base px-8 py-3 rounded-full transition-all duration-200 ${
                currentStep === 0
                  ? "bg-white/5 text-white/30 cursor-not-allowed"
                  : "border-2 border-[#007fff] text-[#007fff] hover:bg-[#007fff] hover:text-white"
              }`}
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              <ArrowLeft size={20} />
              Previous
            </button>

            {currentStep < totalSteps - 1 ? (
              <button
                onClick={handleNext}
                className="flex items-center gap-2 bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-base px-8 py-3 rounded-full transition-all duration-200"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                Next
                <ArrowRight size={20} />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="flex items-center gap-2 bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-base px-8 py-3 rounded-full transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Submit
                    <CheckCircle2 size={20} />
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </section>

      <WachFooter />
    </div>
  );
}
