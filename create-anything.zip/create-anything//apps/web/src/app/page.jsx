import WachHeader from "../components/WachHeader";
import WachFooter from "../components/WachFooter";
import { Play, ArrowRight, Film, Award, Users } from "lucide-react";

export default function HomePage() {
  const portfolioItems = [
    {
      id: 1,
      title: "Corporate Brand Film",
      category: "Corporate",
      thumbnail:
        "https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?w=800&h=600&fit=crop&auto=format&q=80",
      videoUrl: "#",
    },
    {
      id: 2,
      title: "Wedding Highlights",
      category: "Wedding",
      thumbnail:
        "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=600&fit=crop&auto=format&q=80",
    },
    {
      id: 3,
      title: "Music Video Production",
      category: "Music Video",
      thumbnail:
        "https://images.unsplash.com/photo-1598387993441-a364f854c3e1?w=800&h=600&fit=crop&auto=format&q=80",
      videoUrl: "#",
    },
    {
      id: 4,
      title: "Social Media Content",
      category: "Social Media",
      thumbnail:
        "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&h=600&fit=crop&auto=format&q=80",
      videoUrl: "#",
    },
    {
      id: 5,
      title: "Documentary Series",
      category: "Documentary",
      thumbnail:
        "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&h=600&fit=crop&auto=format&q=80",
      videoUrl: "#",
    },
    {
      id: 6,
      title: "Product Commercial",
      category: "Commercial",
      thumbnail:
        "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&h=600&fit=crop&auto=format&q=80",
      videoUrl: "#",
    },
  ];

  const stats = [
    { icon: Film, value: "500+", label: "Videos Edited" },
    { icon: Users, value: "200+", label: "Happy Clients" },
    { icon: Award, value: "50+", label: "Awards Won" },
  ];

  return (
    <div className="min-h-screen bg-[#121212]">
      <WachHeader />

      {/* Hero Section */}
      <section className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#121212] relative flex items-center justify-center px-6 py-32">
        {/* Background gradient overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-96 h-96 bg-[#007fff] rounded-full blur-[120px]"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#007fff] rounded-full blur-[120px]"></div>
        </div>

        <div className="max-w-5xl mx-auto text-center relative z-10">
          {/* Hero headline */}
          <h1
            className="text-[clamp(2.5rem,8vw,5.5rem)] leading-[1.1] font-extrabold text-white tracking-tight mb-6"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            <span className="block">Transforming Your Vision</span>
            <span className="block">
              Into{" "}
              <span className="relative inline-block">
                Cinematic Reality
                <svg
                  className="absolute left-0 -bottom-2 w-full h-3 opacity-50"
                  viewBox="0 0 100 8"
                  fill="none"
                >
                  <path
                    d="M2 6c20-4 40-4 60 0s40 4 36-2"
                    stroke="#007fff"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </span>
          </h1>

          {/* Sub-headline */}
          <p
            className="text-[18px] md:text-[22px] font-normal text-white/70 leading-relaxed mb-12 max-w-3xl mx-auto"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            Professional video editing services that bring your brand story to
            life. From concept to completion, we craft compelling visual
            narratives.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="/onboarding"
              className="bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200 hover:shadow-[0_0_30px_rgba(0,127,255,0.5)] hover:scale-105 min-h-[56px] flex items-center gap-2"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Get Started
              <ArrowRight size={20} />
            </a>

            <a
              href="/#portfolio"
              className="border-2 border-[#007fff] text-[#007fff] hover:bg-[#007fff] hover:text-white font-semibold text-base px-10 py-4 rounded-full transition-all duration-200 min-h-[56px] flex items-center gap-2"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              View Portfolio
              <Play size={20} />
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-full bg-[#007fff]/10 flex items-center justify-center mb-4">
                    <Icon size={32} className="text-[#007fff]" />
                  </div>
                  <div
                    className="text-4xl font-bold text-white mb-2"
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    {stat.value}
                  </div>
                  <div
                    className="text-white/60 font-medium"
                    style={{ fontFamily: "Montserrat, sans-serif" }}
                  >
                    {stat.label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="bg-[#121212] py-20 md:py-28 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Section heading */}
          <div className="text-center mb-16">
            <h2
              className="text-[clamp(2.5rem,7vw,4rem)] leading-[1.1] font-bold text-white mb-4"
              style={{
                fontFamily: "Poppins, sans-serif",
                letterSpacing: "-0.5px",
              }}
            >
              Our Portfolio
            </h2>
            <p
              className="text-white/60 text-lg max-w-2xl mx-auto"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Explore our recent work and see how we bring stories to life
              through video editing
            </p>
          </div>

          {/* Portfolio Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {portfolioItems.map((item) => (
              <a
                key={item.id}
                href={item.videoUrl}
                className="group relative overflow-hidden rounded-lg cursor-pointer aspect-video bg-[#1A1A1A]"
              >
                <img
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-full h-full object-cover transition-all duration-300 group-hover:scale-110"
                />

                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-6">
                  <div className="mb-2">
                    <span
                      className="text-[#007fff] text-sm font-semibold uppercase tracking-wider"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      {item.category}
                    </span>
                  </div>
                  <h3
                    className="text-white text-xl font-bold mb-3"
                    style={{ fontFamily: "Poppins, sans-serif" }}
                  >
                    {item.title}
                  </h3>
                  <div className="flex items-center gap-2 text-white">
                    <Play size={20} />
                    <span
                      className="text-sm font-medium"
                      style={{ fontFamily: "Montserrat, sans-serif" }}
                    >
                      <a href="https://drive.google.com/drive/folders/18ldZT-p1DIRy7GqrdtXkE8U_ic95W6dw">
                        Watch Now
                      </a>
                    </span>
                  </div>
                </div>

                {/* Play button centered */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-20 h-20 rounded-full bg-[#007fff] flex items-center justify-center shadow-[0_0_40px_rgba(0,127,255,0.6)]">
                    <Play size={32} className="text-white ml-1" fill="white" />
                  </div>
                </div>
              </a>
            ))}
          </div>

          {/* View More Button */}
          <div className="text-center mt-12">
            <a
              href="/onboarding"
              className="inline-flex items-center gap-2 border-2 border-[#007fff] text-[#007fff] hover:bg-[#007fff] hover:text-white font-semibold text-base px-8 py-3 rounded-full transition-all duration-200"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Start Your Project
              <ArrowRight size={20} />
            </a>
          </div>
        </div>
      </section>

      {/* Hire Me CTA Section */}
      <section className="bg-gradient-to-b from-[#121212] to-[#0A0A0A] py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#007fff] rounded-full blur-[100px]"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2
            className="text-[clamp(2rem,6vw,3.5rem)] leading-[1.2] font-bold text-white mb-6"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            Ready to Create Something Amazing?
          </h2>
          <p
            className="text-white/70 text-lg md:text-xl mb-10 max-w-2xl mx-auto"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            Let's discuss your project and bring your vision to life with
            professional video editing services.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="/onboarding"
              className="bg-[#007fff] hover:bg-[#0066cc] text-white font-semibold text-lg px-12 py-4 rounded-full transition-all duration-200 hover:shadow-[0_0_30px_rgba(0,127,255,0.5)] hover:scale-105 flex items-center gap-2"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Hire Me Now
              <ArrowRight size={22} />
            </a>

            <a
              href="/booking"
              className="border-2 border-white/30 text-white hover:border-white hover:bg-white/5 font-semibold text-lg px-12 py-4 rounded-full transition-all duration-200 flex items-center gap-2"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Book a Session
            </a>
          </div>
        </div>
      </section>

      <WachFooter />
    </div>
  );
}