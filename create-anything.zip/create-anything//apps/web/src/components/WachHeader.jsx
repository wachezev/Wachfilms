"use client";

import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function WachHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Portfolio", href: "/#portfolio" },
    { label: "Pricing", href: "/pricing" },
    { label: "Book Session", href: "/booking" },
    { label: "Get Started", href: "/onboarding" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A] border-b border-[#007fff]/20">
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-4">
        <div className="flex items-center justify-between">
          {/* Logo/Brand */}
          <a href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-full bg-[#007fff] flex items-center justify-center">
              <span className="text-white font-bold text-lg">W</span>
            </div>
            <span
              className="text-white font-bold text-xl tracking-tight group-hover:text-[#007fff] transition-colors"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Wachfilms
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item, index) => (
              <a
                key={index}
                href={item.href}
                className="text-white/80 font-semibold text-[15px] hover:text-[#007fff] transition-colors duration-200 cursor-pointer"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-white/5 transition-colors duration-150 rounded-md"
          >
            {isMenuOpen ? (
              <X size={24} className="text-white" strokeWidth={2} />
            ) : (
              <Menu size={24} className="text-white" strokeWidth={2} />
            )}
          </button>
        </div>

        {/* Mobile Menu Dropdown */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-[#007fff]/20">
            <nav className="flex flex-col gap-4">
              {navItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-white/80 font-semibold text-[15px] hover:text-[#007fff] transition-colors cursor-pointer"
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
