"use client";

import {
  Mail,
  Phone,
  Instagram,
  Twitter,
  Linkedin,
  Youtube,
} from "lucide-react";

export default function WachFooter() {
  return (
    <footer className="bg-[#0A0A0A] border-t border-[#007fff]/20 py-12 px-6 md:px-16">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6 sm:gap-0">
          {/* Left block - Social icons */}
          <div className="flex items-center gap-7 sm:gap-10">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow on Instagram"
              className="text-white/70 hover:text-[#007fff] transition-all duration-100 ease-out hover:-translate-y-[1px] focus:outline-none focus:ring-2 focus:ring-[#007fff] focus:ring-offset-2 rounded-sm"
            >
              <Instagram size={24} className="cursor-pointer" />
            </a>

            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow on Twitter"
              className="text-white/70 hover:text-[#007fff] transition-all duration-100 ease-out hover:-translate-y-[1px] focus:outline-none focus:ring-2 focus:ring-[#007fff] focus:ring-offset-2 rounded-sm"
            >
              <Twitter size={24} className="cursor-pointer" />
            </a>

            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Connect on LinkedIn"
              className="text-white/70 hover:text-[#007fff] transition-all duration-100 ease-out hover:-translate-y-[1px] focus:outline-none focus:ring-2 focus:ring-[#007fff] focus:ring-offset-2 rounded-sm"
            >
              <Linkedin size={24} className="cursor-pointer" />
            </a>

            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Subscribe on YouTube"
              className="text-white/70 hover:text-[#007fff] transition-all duration-100 ease-out hover:-translate-y-[1px] focus:outline-none focus:ring-2 focus:ring-[#007fff] focus:ring-offset-2 rounded-sm"
            >
              <Youtube size={24} className="cursor-pointer" />
            </a>
          </div>

          {/* Right block - Contact info */}
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
            <div className="flex items-center gap-3">
              <Mail size={20} className="text-[#007fff]" />
              <a
                href="mailto:wachukwuvictor715@gmail.com"
                className="text-[16px] text-white/80 hover:text-[#007fff] transition-colors duration-100 ease-out font-medium"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                wachukwuvictor715@gmail.com
              </a>
            </div>

            <div className="flex items-center gap-3">
              <Phone size={20} className="text-[#007fff]" />
              <a
                href="tel:+2348133959248"
                className="text-[16px] text-white/80 hover:text-[#007fff] transition-colors duration-100 ease-out font-medium"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                +234 813 395 9248
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/10 text-center">
          <p
            className="text-white/50 text-sm"
            style={{ fontFamily: "Montserrat, sans-serif" }}
          >
            © {new Date().getFullYear()} Wachfilms. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}